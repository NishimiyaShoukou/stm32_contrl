#ifndef _USART_H
#define _USART_H

#include"system.h"
#include"stdio.h"
#include"led.h"
#include"oled.h"

void USART1_Init(u32 baud);


#endif
