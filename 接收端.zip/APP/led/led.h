#ifndef _led_H
#define _led_H

#include "system.h"

/*  LEDʱ�Ӷ˿ڡ����Ŷ��� */
#define LED_PORT 			GPIOD  
#define LED_PIN 			(GPIO_Pin_0)
#define LED_PORT_RCC		RCC_APB2Periph_GPIOD


#define led1 PBout(5)
#define led2 PDout(0)



void LED_Init(void);


#endif
