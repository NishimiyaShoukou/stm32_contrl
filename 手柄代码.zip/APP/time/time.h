#ifndef _TIME_H
#define _TIME_H
#include"system.h"
#include"led.h"

void TIME4_Init(u16 pre,u16 psc);



#endif



