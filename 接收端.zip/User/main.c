
#include "system.h"
#include "SysTick.h"
#include "led.h"
#include "usart.h"
#include "key.h"
#include "dma.h"
#include "spi.h"
#include "24l01.h"  
#include "lcd_init.h"
#include "lcd.h"
#include "pic.h"
#include "pwm.h"
#define send_buf_len 5000
u8 send_buf[send_buf_len];
float rx_left_x,rx_left_y;
u8 rx_left_l1,rx_left_l2;
float rx_right_x,rx_right_y;
u8 rx_right_r1,rx_right_r2;
/*******************************************************************************
* �� �� ��         : Send_Data
* ��������		   : Ҫ���͵�����
* ��    ��         : p��ָ�����			 
* ��    ��         : ��
*******************************************************************************/
void Send_Data(u8 *p)
{
	u16 i;
	for(i=0;i<send_buf_len;i++)
	{
		*p='5';
		p++;
	}
}

void forward()
{
	   TIM_SetCompare1(TIM4,400);
		 TIM_SetCompare2(TIM4,0);
		 TIM_SetCompare3(TIM3,400);
		 TIM_SetCompare4(TIM3,0);	
	
}
void back()
{
	   TIM_SetCompare1(TIM4,0);
		 TIM_SetCompare2(TIM4,400);
		 TIM_SetCompare3(TIM3,00);
		 TIM_SetCompare4(TIM3,400);	
	
}
void left()
{
	   TIM_SetCompare1(TIM4,500);
		 TIM_SetCompare2(TIM4,0);
		 TIM_SetCompare3(TIM3,200);
		 TIM_SetCompare4(TIM3,0);	
	
}
void right()
{
	   TIM_SetCompare1(TIM4,200);
		 TIM_SetCompare2(TIM4,0);
		 TIM_SetCompare3(TIM3,500);
		 TIM_SetCompare4(TIM3,0);	
	
}
void left_spin()
{
	   TIM_SetCompare1(TIM4,300);
		 TIM_SetCompare2(TIM4,0);
		 TIM_SetCompare3(TIM3,0);
		 TIM_SetCompare4(TIM3,300);	
	
}
void right_spin()
{
	   TIM_SetCompare1(TIM4,0);
		 TIM_SetCompare2(TIM4,300);
		 TIM_SetCompare3(TIM3,300);
		 TIM_SetCompare4(TIM3,0);	
	
}
void stop()
{
	   TIM_SetCompare1(TIM4,0);
		 TIM_SetCompare2(TIM4,0);
		 TIM_SetCompare3(TIM3,0);
		 TIM_SetCompare4(TIM3,0);	
	
}
/*******************************************************************************
* �� �� ��         : main
* ��������		   : ������
* ��    ��         : ��
* ��    ��         : ��
*******************************************************************************/
int main()
{
	u8 i=0;
	u8 t=0;
	u8 key;
	u8 tmp_buf[33]; 
	u8 rx_buf[14];
	SysTick_Init(72);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //�ж����ȼ����� ��2��
	LED_Init();
	USART1_Init(9600);
	LCD_Init();//LCD��ʼ��
	LCD_Fill(0,0,LCD_W,LCD_H,WHITE);
	TIM3_CH_PWM_Init(1000,72000-1);
	TIM4_CH_PWM_Init(1000,72000-1);
	NRF24L01_Init();    	//��ʼ��NRF24L01  
	while(NRF24L01_Check())	//���NRF24L01�Ƿ���λ.	
	{
		printf("NRF24L01 Error");
		delay_ms(200);
	}		
  NRF24L01_RX_Mode();		

	
	stop();
	LCD_ShowPicture(65,80,40,40,gImage_1);
	while(1)
	{
//		LCD_ShowFloatNum1(20,80,rx_left_x,4,RED,WHITE,16);
//		LCD_ShowFloatNum1(20,100,rx_left_y,4,RED,WHITE,16);
////		LCD_ShowChinese(0,0,"�о�԰����",RED,WHITE,24,0);
////		LCD_ShowString(24,30,"LCD_W:",RED,WHITE,16,0);
//		LCD_ShowIntNum(72,30,LCD_W,3,RED,WHITE,16);
//		LCD_ShowString(24,50,"LCD_H:",RED,WHITE,16,0);
//		LCD_ShowIntNum(72,50,LCD_H,3,RED,WHITE,16);
////		LCD_ShowFloatNum1(20,80,t,4,RED,WHITE,16);
		
	
		i++;
		if(i%20==0)
		{
			led2=!led2;
		}
		
		if(NRF24L01_RxPacket(tmp_buf)==0)//һ�����յ���Ϣ,����ʾ����.
		{
				tmp_buf[32]=0;//�����ַ���������
			for(t=0;t<32;t++)
			{
				if(tmp_buf[t]=='l'&&tmp_buf[t+1]=='x'&&tmp_buf[t+2]==':')
				{
						rx_left_x=(tmp_buf[t+3]-0x30)+(float)(tmp_buf[t+4]-0x30)/10+(float)(tmp_buf[t+5]-0x30)/100+(float)(tmp_buf[t+6]-0x30)/1000;
		        rx_left_y=(tmp_buf[t+7]-0x30)+(float)(tmp_buf[t+8]-0x30)/10+(float)(tmp_buf[t+9]-0x30)/100+(float)(tmp_buf[t+10]-0x30)/1000;
					  rx_left_l1=tmp_buf[t+12]-0x30;
						rx_left_l2=tmp_buf[t+15]-0x30;
						
						
				}
				if(tmp_buf[t]=='r'&&tmp_buf[t+1]=='x'&&tmp_buf[t+2]==':')
				{
						rx_right_x=(tmp_buf[t+3]-0x30)+(float)(tmp_buf[t+4]-0x30)/10+(float)(tmp_buf[t+5]-0x30)/100+(float)(tmp_buf[t+6]-0x30)/1000;
		        rx_right_y=(tmp_buf[t+7]-0x30)+(float)(tmp_buf[t+8]-0x30)/10+(float)(tmp_buf[t+9]-0x30)/100+(float)(tmp_buf[t+10]-0x30)/1000;
					  rx_right_r1=tmp_buf[t+12]-0x30;
						rx_right_r2=tmp_buf[t+15]-0x30;
//							for(i=t;i<t+14;i++)
//							{
//							rx_buf[i]=tmp_buf[i];
//							}
						break;
				}
			  
				
			}
		
				
		}else delay_us(100);
//    LCD_ShowString(4,30,rx_buf,RED,WHITE,16,0);
		if(rx_left_y<0.8)
		{
			  forward();
			
			
		}
		else if(rx_left_y>2.5)
		{
			  back();
			
			
		}
		
		else if(rx_left_x>2.5)
		{
			 right();
		}
		else if(rx_left_x<0.8)
		{
			 left();
		}	
		else if(rx_right_x>2.5)
		{
			 right_spin();
		}
		else  if(rx_right_x<0.8)
		{
			 left_spin();
			
		}
		else
		{
			
			 stop();
		}
		
	}	
}
