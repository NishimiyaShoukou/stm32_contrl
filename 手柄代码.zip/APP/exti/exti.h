#ifndef _exti_H
#define _exti_H

#include"system.h"
#include"SysTick.h"
#include"led.h"
#include"key.h"

void My_EXTI_Init(void);


#endif
