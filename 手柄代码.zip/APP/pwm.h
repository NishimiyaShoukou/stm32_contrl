#ifndef _PWM_H
#define _PWM_H
#include "system.h"



void TIM1_PWM_Init(u16 arr,u16 psc);
void TIM3_PWM_Init(u16 arr,u16 psc);
#endif
