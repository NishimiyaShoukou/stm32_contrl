#ifndef _PWM_H
#define _PWM_H 

#include"system.h"

void TIM2_CH3_PWM_Init(u16 per,u16 psc);
void TIM3_CH_PWM_Init(u16 pre,u16 psc);
void TIM4_CH_PWM_Init(u16 per,u16 psc);

#endif
